# student with phone > 2025-12-15 9:00am
https://universe.roboflow.com/vinoth-sqvrp/student-with-phone-rgtfl

Provided by a Roboflow user
License: CC BY 4.0

