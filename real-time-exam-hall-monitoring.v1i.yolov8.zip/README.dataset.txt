# real-time-exam-hall-monitoring > 2025-12-15 9:21am
https://universe.roboflow.com/vinoth-sqvrp/real-time-exam-hall-monitoring-zwots

Provided by a Roboflow user
License: MIT

